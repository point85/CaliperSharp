var searchData=
[
  ['equals_0',['Equals',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_quantity.html#ada8e508fde5202a3d95f0b5516678ed5',1,'Point85.Caliper.UnitOfMeasure.Quantity.Equals()'],['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a9ff5f4c695fedd9dec5fdb286fc448a7',1,'Point85.Caliper.UnitOfMeasure.UnitOfMeasure.Equals()']]]
];
