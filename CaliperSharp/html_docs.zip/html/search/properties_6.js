var searchData=
[
  ['name_0',['Name',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#a052654e95d0ee7226dbc6a317cbc0a1c',1,'Point85.Caliper.UnitOfMeasure.Prefix.Name'],['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_symbolic.html#a2c51a7a8d7e451b017a5cc94ed813ea5',1,'Point85.Caliper.UnitOfMeasure.Symbolic.Name']]]
];
