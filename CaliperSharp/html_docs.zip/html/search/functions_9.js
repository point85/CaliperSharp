var searchData=
[
  ['quantity_0',['Quantity',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_quantity.html#a258f7709c96a0a8987a567103dbfc4f0',1,'Point85.Caliper.UnitOfMeasure.Quantity.Quantity()'],['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_quantity.html#adc36ed9ecddbcf78a272b49a4f787aba',1,'Point85.Caliper.UnitOfMeasure.Quantity.Quantity(double amount, UnitOfMeasure uom)'],['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_quantity.html#a3f90cb724d9fff3d2fb29065e7befe48',1,'Point85.Caliper.UnitOfMeasure.Quantity.Quantity(double amount, Prefix prefix, Unit unit)'],['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_quantity.html#a3e8321aba3c9a800ee73c4a73af22a5d',1,'Point85.Caliper.UnitOfMeasure.Quantity.Quantity(double amount, Unit unit)']]]
];
