var searchData=
[
  ['kibi_0',['KIBI',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#a7176057ed3843f760cef8aca3ffe0def',1,'Point85::Caliper::UnitOfMeasure::Prefix']]],
  ['kilo_1',['KILO',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#aedabe11da2a2ebaab98396a8f6dd3424',1,'Point85::Caliper::UnitOfMeasure::Prefix']]]
];
