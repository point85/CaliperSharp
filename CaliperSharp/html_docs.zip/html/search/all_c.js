var searchData=
[
  ['offset_0',['Offset',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a1ab67397e6cb0a42f3aa0f1abe43393f',1,'Point85::Caliper::UnitOfMeasure::UnitOfMeasure']]]
];
