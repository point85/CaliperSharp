var searchData=
[
  ['power_0',['Power',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_quantity.html#a69609d75732a2ef6bf4c0f6eb1fb3157',1,'Point85.Caliper.UnitOfMeasure.Quantity.Power()'],['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a30ca7f40a50109a4fca75de6ddb96ef5',1,'Point85.Caliper.UnitOfMeasure.UnitOfMeasure.Power()']]],
  ['prefix_1',['Prefix',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#a17e4ac00f280d1da0a76825cd8e05e62',1,'Point85::Caliper::UnitOfMeasure::Prefix']]]
];
