var searchData=
[
  ['deci_0',['DECI',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#a4ecd02d8aa985a88f0fb6606961a3c52',1,'Point85::Caliper::UnitOfMeasure::Prefix']]],
  ['deka_1',['DEKA',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#aa81932873f8c63a67cec2f92860447ae',1,'Point85::Caliper::UnitOfMeasure::Prefix']]]
];
