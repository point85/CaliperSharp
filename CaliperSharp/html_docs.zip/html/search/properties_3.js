var searchData=
[
  ['description_0',['Description',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_symbolic.html#afd1a4a200c383a68a723f5030460f455',1,'Point85::Caliper::UnitOfMeasure::Symbolic']]]
];
