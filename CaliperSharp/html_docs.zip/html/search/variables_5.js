var searchData=
[
  ['gibi_0',['GIBI',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#a9ee33b3c9f4e13b86fcd8442336fd335',1,'Point85::Caliper::UnitOfMeasure::Prefix']]],
  ['giga_1',['GIGA',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#a3bf8b73193385d9a1ceaf136fd8c0d3c',1,'Point85::Caliper::UnitOfMeasure::Prefix']]]
];
