var searchData=
[
  ['uom_0',['UOM',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_quantity.html#aaab6dff19bb9ba1078a4bae37ce4f350',1,'Point85::Caliper::UnitOfMeasure::Quantity']]],
  ['uomtype_1',['UOMType',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a01e025fc0ecbc625d796439b7d38efbf',1,'Point85::Caliper::UnitOfMeasure::UnitOfMeasure']]]
];
