var searchData=
[
  ['scalingfactor_0',['ScalingFactor',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a46b0819f9b19aff3b51c178b414616f6',1,'Point85::Caliper::UnitOfMeasure::UnitOfMeasure']]],
  ['symbol_1',['Symbol',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_prefix.html#a88a73f550dd6f1b00b2baee67348faba',1,'Point85.Caliper.UnitOfMeasure.Prefix.Symbol'],['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_symbolic.html#ac809b4a85c0339edf489458a3c693ef7',1,'Point85.Caliper.UnitOfMeasure.Symbolic.Symbol']]]
];
