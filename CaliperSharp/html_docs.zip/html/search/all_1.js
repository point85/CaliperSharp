var searchData=
[
  ['bridgeabscissaunit_0',['BridgeAbscissaUnit',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a8cdcf4810ba04229a7a9f04ef5365ba8',1,'Point85::Caliper::UnitOfMeasure::UnitOfMeasure']]],
  ['bridgeoffset_1',['BridgeOffset',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a391c933955e74a059b9c2e5d6f738eb9',1,'Point85::Caliper::UnitOfMeasure::UnitOfMeasure']]],
  ['bridgescalingfactor_2',['BridgeScalingFactor',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a0b6d5538c4d7eec45113ae5fc4236d4b',1,'Point85::Caliper::UnitOfMeasure::UnitOfMeasure']]]
];
