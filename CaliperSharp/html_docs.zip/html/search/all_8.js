var searchData=
[
  ['invert_0',['Invert',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_quantity.html#a235ecfc8af27b1e382236a1abe773c09',1,'Point85.Caliper.UnitOfMeasure.Quantity.Invert()'],['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a1952cdbdf4b1abc58e3a30f9a32add54',1,'Point85.Caliper.UnitOfMeasure.UnitOfMeasure.Invert()']]],
  ['isterminal_1',['IsTerminal',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a5647a1665e4b7174d228b422d5072561',1,'Point85::Caliper::UnitOfMeasure::UnitOfMeasure']]]
];
