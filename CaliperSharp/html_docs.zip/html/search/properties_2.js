var searchData=
[
  ['category_0',['Category',['../class_point85_1_1_caliper_1_1_unit_of_measure_1_1_unit_of_measure.html#a5f8bc0bc6755aa6b761bad829117a6b2',1,'Point85::Caliper::UnitOfMeasure::UnitOfMeasure']]]
];
